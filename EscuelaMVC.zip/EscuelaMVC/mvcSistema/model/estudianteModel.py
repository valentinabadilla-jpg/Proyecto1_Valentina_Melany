class Estudiante:
    def __init__(self, nombre, apellidos, edad, telefono, direccion, fecha_nacimiento, grado, correo):
        self.nombre = nombre
        self.apellidos = apellidos
        self.edad = edad
        self.telefono = telefono
        self.direccion = direccion
        self.fecha_nacimiento = fecha_nacimiento
        self.grado = grado
        self.correo = correo